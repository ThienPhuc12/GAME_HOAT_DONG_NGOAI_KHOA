#pragma once
// =============================================================================
//  LE PONT · CẦU — page grand écran + télécommande — http://192.168.4.1/host
//  Généré depuis web/host.html : modifie le .html puis relance gen_web_h.py,
//  ou édite directement ci-dessous (c'est du HTML/JS ordinaire).
// =============================================================================
const char HOST_HTML[] PROGMEM = R"html(
<!doctype html>
<html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Le Pont · Cầu — grand écran</title>
<style>
body{margin:0;background:#0b1020;color:#f8fafc;font-family:system-ui,"Segoe UI",Roboto,sans-serif}
.top{display:flex;justify-content:space-between;align-items:center;padding:10px 28px;font-size:18px;color:#94a3b8}
.main{padding:0 40px 70px}
.q{font-size:36px;line-height:1.25;margin:8px 0}.qvi{font-size:26px;color:#cbd5e1}
.opts{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin:14px 0}
.opt{font-size:25px;padding:14px 20px;border-radius:14px;background:#1e293b}
.opt.ok{background:#16a34a}.opt.dim{opacity:.35}
.timer{font-size:64px;font-weight:700;text-align:center;width:120px;flex:none}
.bar{height:14px;background:#1e293b;border-radius:7px;overflow:hidden;flex:1}.bar i{display:block;height:100%;background:#f59e0b;transition:width 1s linear;width:100%}
.rev{font-size:21px;line-height:1.4;margin:6px 0;color:#e2e8f0}
.scores{display:flex;gap:24px;margin:12px 0}.sc{flex:1;padding:12px 20px;border-radius:14px;font-size:26px;display:flex;justify-content:space-between}
.ctl{position:fixed;bottom:16px;right:16px;display:flex;gap:8px;opacity:.35;transition:opacity .2s}.ctl:hover{opacity:1}
.ctl button{font-size:16px;padding:10px 16px;border:0;border-radius:10px;background:#334155;color:#fff;cursor:pointer}
.ctl button.p{background:#f59e0b;color:#111;font-weight:600}
.lobby{text-align:center;padding:30px 0}.lobby h1{font-size:60px;margin:0}.lobby .join{font-size:32px;margin:18px 0;color:#fbbf24}
.pl{display:flex;flex-wrap:wrap;gap:10px;justify-content:center;margin:16px 0;min-height:48px}.pl span{padding:8px 16px;border-radius:999px;font-size:22px}
svg{width:100%;height:140px;display:block;margin:8px 0}
.hide{display:none}
</style></head><body>
<div class="top"><div id="ssid">Le Pont · Cầu</div><div id="qn"></div><div id="cnt"></div></div>
<div class="main">
 <div id="v-lobby" class="lobby">
  <h1>🇫🇷 Le Pont · Cầu 🇻🇳</h1>
  <div class="join">Wi-Fi : <b id="ssid2">LePont-1</b> &nbsp;→&nbsp; <b>http://192.168.4.1</b></div>
  <div class="pl" id="pl"></div>
 </div>
 <div id="v-q" class="hide">
  <div style="display:flex;align-items:center;gap:24px"><div class="timer" id="timer">20</div><div class="bar"><i id="bar"></i></div></div>
  <p class="q" id="fr"></p><p class="q qvi" id="vi"></p>
  <div class="opts" id="opts"></div>
  <p class="rev hide" id="pfr"></p><p class="rev qvi hide" id="pvi"></p>
 </div>
 <div id="v-end" class="hide lobby"><h1>Fin · Kết thúc</h1><div id="winner" class="join"></div></div>
 <svg id="bridge" viewBox="0 0 1000 140" preserveAspectRatio="none"></svg>
 <div class="scores" id="scores"></div>
</div>
<div class="ctl">
 <button onclick="cmd('reset')">Reset</button>
 <button onclick="cmd('reveal')">Révéler</button>
 <button class="p" id="btn" onclick="next()">Lancer</button>
</div>
<script>
var ws,TEAMS=[],state='lobby',cur=null,spans=0,total=10;
function $(i){return document.getElementById(i)}
function tcol(i){return TEAMS[i]?TEAMS[i].c:'#64748b'}
function tname(i){return TEAMS[i]?TEAMS[i].n:'Equipe '+(i+1)}
function connect(){
 ws=new WebSocket('ws://'+location.host+'/ws');
 ws.onopen=function(){ws.send(JSON.stringify({t:'hello',role:'host'}))};
 ws.onclose=function(){setTimeout(connect,2000)};
 ws.onerror=function(){};
 ws.onmessage=function(e){var m;try{m=JSON.parse(e.data)}catch(x){return}handle(m)};
}
function cmd(c){if(ws&&ws.readyState===1)ws.send(JSON.stringify({t:'host',cmd:c}))}
function next(){cmd(state==='lobby'?'start':'next')}
function view(v){['v-lobby','v-q','v-end'].forEach(function(x){$(x).classList.toggle('hide',x!==v)})}
function scores(sc){$('scores').innerHTML=(sc||[]).map(function(s,i){return '<div class="sc" style="background:'+tcol(i)+'"><span>'+tname(i)+'</span><b>'+s+'</b></div>'}).join('')}
function bridge(){
 var h='<rect x="0" y="100" width="140" height="40" fill="#2b6cb0"/><rect x="860" y="100" width="140" height="40" fill="#c53030"/>'+
  '<text x="16" y="90" fill="#93c5fd" font-size="22">France</text><text x="884" y="90" fill="#fca5a5" font-size="22">Việt Nam</text>';
 var w=720/total;
 for(var i=0;i<total;i++){
  var lit=i<spans, k=(i%2===0)?Math.floor(i/2):total-1-Math.floor(i/2), x=140+k*w;
  h+='<rect x="'+(x+2)+'" y="'+(lit?55:88)+'" width="'+(w-4)+'" height="'+(lit?45:10)+'" rx="4" fill="'+(lit?'#f59e0b':'#334155')+'"/>';
 }
 $('bridge').innerHTML=h;
}
function handle(m){
 if(m.t==='config'){TEAMS=m.teams||[];total=m.total||10;$('ssid').textContent=m.ssid;$('ssid2').textContent=m.ssid;bridge()}
 else if(m.t==='lobby'){
  state='lobby';view('v-lobby');$('btn').textContent='Lancer';$('qn').textContent='';
  $('pl').innerHTML=m.players.map(function(p){return '<span style="background:'+tcol(p.team)+'">'+p.n+'</span>'}).join('');
  $('cnt').textContent=m.players.length+' joueur'+(m.players.length>1?'s':'');scores(m.scores);spans=0;bridge();
 }
 else if(m.t==='question'){
  state='q';cur=m;view('v-q');$('btn').textContent='Suivante';
  $('qn').textContent='Question '+(m.i+1)+' / '+m.n+' · '+m.cat;
  $('fr').textContent=m.fr;$('vi').textContent=m.vi;
  $('opts').innerHTML=m.o.map(function(o,k){return '<div class="opt" id="o'+k+'">'+'ABCD'[k]+'. '+o+'</div>'}).join('');
  $('pfr').classList.add('hide');$('pvi').classList.add('hide');
  $('timer').textContent=m.sec;$('bar').style.width='100%';$('cnt').textContent='0 réponse';
 }
 else if(m.t==='tick'){
  $('timer').textContent=m.left;$('bar').style.width=(100*m.left/(cur?cur.sec:20))+'%';
  if(m.answers!==undefined)$('cnt').textContent=m.answers+' réponse'+(m.answers>1?'s':'');
 }
 else if(m.t==='reveal'){
  state='rev';for(var k=0;k<4;k++){var o=$('o'+k);if(o)o.className='opt '+(k===m.r?'ok':'dim')}
  $('pfr').textContent=m.pfr;$('pvi').textContent=m.pvi;$('pfr').classList.remove('hide');$('pvi').classList.remove('hide');
  $('timer').textContent='✓';scores(m.scores);if(m.spans!==undefined)spans=m.spans;bridge();
 }
 else if(m.t==='end'){
  state='end';view('v-end');var w=m.winner||0;$('qn').textContent='';$('cnt').textContent='';
  $('winner').textContent='Victoire : '+tname(w)+' · '+(spans===total?'Le pont est complet !':spans+' travée'+(spans>1?'s':'')+' sur '+total);
  scores(m.scores);if(m.spans!==undefined)spans=m.spans;bridge();$('btn').textContent='Rejouer';
 }
 else if(m.t==='reset'){state='lobby';view('v-lobby');spans=0;bridge()}
}
bridge();connect();
</script></body></html>

)html";
