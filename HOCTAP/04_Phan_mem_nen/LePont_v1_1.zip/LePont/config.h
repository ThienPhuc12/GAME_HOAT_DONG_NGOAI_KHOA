#pragma once
// =============================================================================
//  LE PONT · CẦU — configuration
//  Change uniquement ce qui concerne ton groupe. Tout le reste du jeu s'adapte.
// =============================================================================

#define GROUP_ID 1              // Numéro de ton groupe (1 à 7). Donne le nom du Wi-Fi : LePont-1, LePont-2…
#define QUESTION_SECONDS 20     // Temps pour répondre à chaque question
#define QUESTIONS_PER_GAME 10   // Nombre de questions par partie (= nombre de travées du pont)
#define MAX_PLAYERS 10          // Joueurs maximum connectés à l'objet
#define TEAM_COUNT 2            // Nombre d'équipes (2 à 4)

// Noms et couleurs des équipes (téléphones et grand écran)
static const char* TEAM_NAMES[4]  = {"Rive France", "Rive Vietnam", "Equipe 3", "Equipe 4"};
static const char* TEAM_COLORS[4] = {"#2b6cb0", "#c53030", "#2f855a", "#b7791f"};

// ----------------------------- Écran de l'objet ------------------------------
// 0 = aucun écran (Tutoriel 1 : tout se lit sur le moniteur série)
// 2 = GC9A01 1.28" 240x240 rond — l'écran de l'atelier (Tutoriel 2)
// 1 = ST7789 1.3" 240x240 carré (si un groupe a cet écran-là)
#define DISPLAY_TYPE 0

// Câblage SPI de l'écran sur l'ESP32-S3 DevKitC (broches libres, hors PSRAM et USB)
//   écran   -> ESP32-S3
//   VCC     -> 3V3
//   GND     -> GND
#define PIN_SCK  12   // SCL / CLK
#define PIN_MOSI 11   // SDA / DIN / MOSI
#define PIN_CS   10   // CS
#define PIN_DC    9   // DC / RS
#define PIN_RST   8   // RES / RST
#define PIN_BL    7   // BLK / LED (rétroéclairage) ; mettre -1 si câblé directement sur 3V3

// ----------------------------- Tactile (Niveau 2) ----------------------------
// 0 = écran sans tactile (7 broches) — tout le jeu se pilote depuis la page /host
// 1 = écran tactile CST816S (12 broches) : un tap = question suivante, appui long = nouvelle partie
#define TOUCH_ENABLE 0

// Câblage I2C du tactile (broches libres de l'ESP32-S3 DevKitC)
//   écran    -> ESP32-S3
//   TP_SDA   -> 5
//   TP_SCL   -> 6
//   TP_INT   -> 4     (facultatif : mettre -1 si non câblé)
//   TP_RST   -> 15    (facultatif : mettre -1 si non câblé)
#define PIN_TP_SDA  5
#define PIN_TP_SCL  6
#define PIN_TP_INT  4
#define PIN_TP_RST 15

// ----------------------------- Wi-Fi -----------------------------------------
// Sept objets dans la même salle : chaque groupe a son canal pour ne pas gêner les autres.
static const uint8_t WIFI_CHANNELS[7] = {1, 6, 11, 1, 6, 11, 1};
#define WIFI_PASSWORD ""        // Réseau ouvert par défaut. 8 caractères minimum pour le protéger.
