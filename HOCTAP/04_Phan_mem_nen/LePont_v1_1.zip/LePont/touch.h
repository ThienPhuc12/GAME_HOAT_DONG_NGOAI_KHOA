#pragma once
#include "config.h"
// =============================================================================
//  LE PONT · CẦU — le tactile de l'objet (Niveau 2, écran CST816S)
//
//  Le contrôleur tactile CST816S parle en I2C à l'adresse 0x15. Il n'a besoin
//  d'aucune bibliothèque : on lit 6 octets à partir du registre 0x01 et on y
//  trouve le geste, le nombre de doigts et la position (x, y) du doigt.
//
//      registre  contenu
//      0x01      geste  (0x01 glisser haut, 0x02 bas, 0x03 gauche, 0x04 droite,
//                        0x05 tap simple, 0x0B double tap, 0x0C appui long)
//      0x02      nombre de doigts (0 ou 1)
//      0x03-0x04 X sur 12 bits      0x05-0x06 Y sur 12 bits
//
//  Le jeu n'appelle que deux fonctions : touchBegin() au démarrage et
//  touchPoll() à chaque tour de loop(), qui renvoie l'événement détecté.
// =============================================================================

enum TouchEvent { TOUCH_NONE, TOUCH_TAP, TOUCH_LONG };

#if TOUCH_ENABLE == 0
void touchBegin() {}
TouchEvent touchPoll() { return TOUCH_NONE; }
int touchX() { return -1; }
int touchY() { return -1; }

#else
#include <Wire.h>

static const uint8_t CST816S_ADDR = 0x15;
static int  tpX = -1, tpY = -1;
static bool tpDown = false;
static uint32_t tpDownAt = 0;
static bool tpLongSent = false;

static const uint32_t TAP_MAX_MS  = 400;    // relâché avant 400 ms : tap
static const uint32_t LONG_MIN_MS = 1200;   // maintenu 1,2 s : appui long

// Lit l'état du contrôleur. Renvoie false si le CST816S ne répond pas
// (il dort quand on ne le touche pas : c'est normal, pas une panne).
static bool cst816sRead(uint8_t& fingers, uint8_t& gesture, int& x, int& y) {
  Wire.beginTransmission(CST816S_ADDR);
  Wire.write(0x01);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom((int)CST816S_ADDR, 6) != 6) return false;
  uint8_t b[6];
  for (int i = 0; i < 6; i++) b[i] = Wire.read();
  gesture = b[0];
  fingers = b[1] & 0x0F;
  x = ((b[2] & 0x0F) << 8) | b[3];
  y = ((b[4] & 0x0F) << 8) | b[5];
  return true;
}

void touchBegin() {
  if (PIN_TP_INT >= 0) pinMode(PIN_TP_INT, INPUT_PULLUP);
  if (PIN_TP_RST >= 0) {               // impulsion de reset : le contrôleur démarre propre
    pinMode(PIN_TP_RST, OUTPUT);
    digitalWrite(PIN_TP_RST, LOW);  delay(10);
    digitalWrite(PIN_TP_RST, HIGH); delay(60);
  }
  Wire.begin(PIN_TP_SDA, PIN_TP_SCL, 400000);
  uint8_t f, g; int x, y;
  bool ok = cst816sRead(f, g, x, y);
  Serial.printf("[tactile] CST816S sur SDA %d / SCL %d : %s\n", PIN_TP_SDA, PIN_TP_SCL,
                ok ? "present" : "silencieux (il repond au premier contact)");
}

// À appeler souvent (chaque loop). Détecte tap et appui long à partir des
// transitions doigt posé / doigt levé : plus fiable que le registre « geste »,
// qui varie d'un lot de dalles à l'autre.
TouchEvent touchPoll() {
  static uint32_t lastRead = 0;
  if (millis() - lastRead < 20) return TOUCH_NONE;   // 50 lectures par seconde suffisent
  lastRead = millis();

  // Si INT est câblé : haut = rien ne se passe, inutile d'interroger l'I2C
  if (PIN_TP_INT >= 0 && !tpDown && digitalRead(PIN_TP_INT) == HIGH) return TOUCH_NONE;

  uint8_t fingers = 0, gesture = 0; int x = 0, y = 0;
  bool ok = cst816sRead(fingers, gesture, x, y);
  bool down = ok && fingers > 0;

  if (down) { tpX = x; tpY = y; }

  if (down && !tpDown) {                       // doigt posé
    tpDown = true; tpDownAt = millis(); tpLongSent = false;
  }
  else if (down && tpDown && !tpLongSent && millis() - tpDownAt >= LONG_MIN_MS) {
    tpLongSent = true;                         // appui long : signalé une seule fois, sans attendre le relâché
    return TOUCH_LONG;
  }
  else if (!down && tpDown) {                  // doigt levé
    tpDown = false;
    uint32_t held = millis() - tpDownAt;
    if (!tpLongSent && held < TAP_MAX_MS) return TOUCH_TAP;
  }
  return TOUCH_NONE;
}

int touchX() { return tpX; }
int touchY() { return tpY; }
#endif
