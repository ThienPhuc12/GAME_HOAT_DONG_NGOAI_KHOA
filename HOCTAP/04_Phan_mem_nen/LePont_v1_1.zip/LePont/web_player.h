#pragma once
// =============================================================================
//  LE PONT · CẦU — page des joueurs (téléphones) — http://192.168.4.1/
//  Généré depuis web/player.html : modifie le .html puis relance gen_web_h.py,
//  ou édite directement ci-dessous (c'est du HTML/JS ordinaire).
// =============================================================================
const char PLAYER_HTML[] PROGMEM = R"html(
<!doctype html>
<html lang="fr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
<title>Le Pont · Cầu</title>
<style>
:root{--bg:#0f172a;--card:#1e293b;--txt:#f1f5f9;--mut:#94a3b8;--ok:#22c55e;--ko:#ef4444;--acc:#f59e0b}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
body{margin:0;font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;background:var(--bg);color:var(--txt);min-height:100vh}
.wrap{max-width:480px;margin:0 auto;padding:16px}
h1{font-size:22px;margin:8px 0 4px}.sub{color:var(--mut);font-size:14px;margin:0 0 12px}
.card{background:var(--card);border-radius:14px;padding:16px;margin:12px 0}
input{width:100%;font-size:18px;padding:12px;border-radius:10px;border:1px solid #334155;background:#0b1220;color:var(--txt)}
button{width:100%;font-size:18px;padding:14px;border:0;border-radius:12px;color:#fff;background:#334155;margin:6px 0}
button.primary{background:var(--acc);color:#111;font-weight:600}
.teams{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.team{padding:12px;border-radius:10px;text-align:center;border:3px solid transparent;opacity:.75;font-weight:600}
.team.sel{border-color:#fff;opacity:1}
.opt{display:block;width:100%;text-align:left;font-size:17px;padding:14px;margin:8px 0;border-radius:12px;background:#334155;color:#fff;border:0}
.opt.sel{outline:3px solid #fff}
.opt.ok{background:var(--ok)}.opt.ko{background:var(--ko)}
.q{font-size:19px;line-height:1.35;margin:6px 0}.qvi{color:#cbd5e1;font-size:16px}
.bar{height:8px;background:#334155;border-radius:4px;overflow:hidden;margin:10px 0}
.bar i{display:block;height:100%;background:var(--acc);width:100%;transition:width 1s linear}
.big{font-size:36px;font-weight:700;text-align:center;margin:8px 0}
.pill{display:inline-block;padding:4px 10px;border-radius:999px;font-size:13px;background:#334155;color:var(--mut)}
.hide{display:none}
ul.list{list-style:none;padding:0;margin:0}.list li{padding:6px 0;border-bottom:1px solid #334155}
.rev{font-size:15px;line-height:1.45;color:#e2e8f0;margin-top:8px}
.status{position:fixed;top:0;left:0;right:0;padding:5px 10px;font-size:12px;text-align:center;background:#7f1d1d;color:#fff;z-index:9}
</style></head><body>
<div id="st" class="status hide">Connexion à l'objet… · Đang kết nối…</div>
<div class="wrap">
 <h1>🇫🇷 Le Pont · Cầu 🇻🇳</h1>
 <p class="sub" id="sub">Rejoins la partie · Tham gia</p>

 <div id="s-join" class="card">
  <input id="name" placeholder="Ton prénom · Tên của bạn" maxlength="16" autocomplete="off">
  <p class="sub" style="margin:12px 0 6px">Ton équipe · Đội của bạn</p>
  <div class="teams" id="teams"></div>
  <button class="primary" onclick="join()">Rejoindre · Tham gia</button>
 </div>

 <div id="s-lobby" class="card hide">
  <p>En attente du lancement… · Chờ bắt đầu… <span class="pill" id="np">0</span></p>
  <ul class="list" id="players"></ul>
 </div>

 <div id="s-q" class="card hide">
  <span class="pill" id="qn"></span> <span class="pill" id="qcat"></span>
  <div class="bar"><i id="bar"></i></div>
  <p class="q" id="qfr"></p>
  <p class="q qvi" id="qvi"></p>
  <div id="opts"></div>
  <p class="sub" id="qmsg"></p>
 </div>

 <div id="s-rev" class="card hide">
  <div class="big" id="verdict"></div>
  <p class="sub" id="pts" style="text-align:center"></p>
  <p class="q" id="rq"></p>
  <div id="ropts"></div>
  <p class="rev" id="rfr"></p>
  <p class="rev qvi" id="rvi"></p>
 </div>

 <div id="s-end" class="card hide">
  <div class="big">Fin · Kết thúc</div>
  <ul class="list" id="final"></ul>
 </div>

 <div class="card">
  <p class="sub" style="margin:0 0 6px">Scores</p>
  <ul class="list" id="scores"></ul>
 </div>
</div>
<script>
var TEAMS=[],me={name:'',team:0,id:0},ws,cur=null,myAns=-1;
function $(i){return document.getElementById(i)}
function show(id){['s-join','s-lobby','s-q','s-rev','s-end'].forEach(function(s){$(s).classList.toggle('hide',s!==id)})}
function tcol(i){return TEAMS[i]?TEAMS[i].c:'#64748b'}
function tname(i){return TEAMS[i]?TEAMS[i].n:'Equipe '+(i+1)}
function connect(){
 ws=new WebSocket('ws://'+location.host+'/ws');
 ws.onopen=function(){$('st').classList.add('hide');if(me.name)send({t:'join',name:me.name,team:me.team})};
 ws.onclose=function(){$('st').classList.remove('hide');setTimeout(connect,2000)};
 ws.onerror=function(){};
 ws.onmessage=function(e){var m;try{m=JSON.parse(e.data)}catch(x){return}handle(m)};
}
function send(o){if(ws&&ws.readyState===1)ws.send(JSON.stringify(o))}
function join(){
 var n=$('name').value.trim();if(!n){$('name').focus();return}
 me.name=n;try{localStorage.setItem('lp_name',n);localStorage.setItem('lp_team',me.team)}catch(x){}
 send({t:'join',name:n,team:me.team});
}
function renderTeams(){
 var h='';TEAMS.forEach(function(t,i){h+='<div class="team'+(i===me.team?' sel':'')+'" style="background:'+t.c+'" onclick="pickTeam('+i+')">'+t.n+'</div>'});
 $('teams').innerHTML=h;
}
function pickTeam(i){me.team=i;renderTeams()}
function renderScores(sc){
 $('scores').innerHTML=(sc||[]).map(function(s,i){return '<li><span style="color:'+tcol(i)+'">●</span> '+tname(i)+' — <b>'+s+'</b></li>'}).join('');
}
function handle(m){
 if(m.t==='config'){TEAMS=m.teams||[];if(me.team>=TEAMS.length)me.team=0;renderTeams();$('sub').textContent='Objet : '+m.ssid}
 else if(m.t==='joined'){me.id=m.id;$('sub').textContent=me.name+' · '+tname(me.team)}
 else if(m.t==='full'){$('sub').textContent='Objet complet · Đã đủ người'}
 else if(m.t==='lobby'){
  if(me.id)show('s-lobby');
  $('np').textContent=m.players.length+(m.players.length>1?' joueurs':' joueur');
  $('players').innerHTML=m.players.map(function(p){return '<li><span style="color:'+tcol(p.team)+'">●</span> '+p.n+'</li>'}).join('');
  renderScores(m.scores);
 }
 else if(m.t==='question'){
  if(!me.id)return;
  cur=m;myAns=-1;show('s-q');
  $('qn').textContent='Question '+(m.i+1)+'/'+m.n;$('qcat').textContent=m.cat;
  $('qfr').textContent=m.fr;$('qvi').textContent=m.vi;$('qmsg').textContent='';
  $('opts').innerHTML=m.o.map(function(o,k){return '<button class="opt" id="o'+k+'" onclick="answer('+k+')">'+'ABCD'[k]+'. '+o+'</button>'}).join('');
  setBar(m.sec,m.sec);
 }
 else if(m.t==='tick'){setBar(m.left,cur?cur.sec:20)}
 else if(m.t==='you'){$('pts').textContent=m.pts>0?('+'+m.pts+' points'):''}
 else if(m.t==='reveal'){
  if(!me.id||!cur)return;
  show('s-rev');var ok=(myAns===m.r);
  $('verdict').textContent=myAns<0?'⏱ Pas de réponse':(ok?'✅ Bravo !':'❌ Raté');
  $('verdict').style.color=ok?'#22c55e':(myAns<0?'#94a3b8':'#ef4444');
  $('rq').textContent=cur.fr;
  $('ropts').innerHTML=cur.o.map(function(o,k){var c=k===m.r?' ok':(k===myAns?' ko':'');return '<div class="opt'+c+'">'+'ABCD'[k]+'. '+o+'</div>'}).join('');
  $('rfr').textContent=m.pfr;$('rvi').textContent=m.pvi;renderScores(m.scores);
 }
 else if(m.t==='end'){
  show('s-end');
  $('final').innerHTML=(m.scores||[]).map(function(s,i){return '<li><span style="color:'+tcol(i)+'">●</span> '+tname(i)+' — <b>'+s+'</b></li>'}).join('');
  renderScores(m.scores);
 }
 else if(m.t==='reset'){me.id=0;cur=null;show('s-join')}
}
function answer(k){
 if(myAns>=0||!cur)return;myAns=k;
 for(var i=0;i<4;i++){var b=$('o'+i);if(b){b.classList.toggle('sel',i===k);b.disabled=true}}
 send({t:'answer',a:k});$('qmsg').textContent='Réponse envoyée · Đã gửi';
}
function setBar(left,total){$('bar').style.width=Math.max(0,Math.min(100,100*left/(total||1)))+'%'}
try{var n=localStorage.getItem('lp_name');if(n)$('name').value=n;var t=localStorage.getItem('lp_team');if(t)me.team=parseInt(t)||0}catch(x){}
connect();
</script></body></html>

)html";
