/*
  DÉMO ANIMATION — Le Pont · Cầu
  Mesure ce que l'écran rond GC9A01 + ESP32-S3 tiennent en animation, avec la
  technique retenue pour le jeu : un canvas en mémoire (dessin hors écran, puis
  envoi du bloc complet), 30 images par seconde visées, zéro scintillement.

  La démo enchaîne en boucle les quatre scènes du jeu :
    ACCUEIL     les deux rives, des joueurs qui rejoignent (points sur le pourtour)
    QUESTION    anneau de temps qui se vide, travées déjà posées, chiffre au centre
    RÉVÉLATION  une travée descend et se pose (ou tombe dans l'eau)
    FIN         pont complet, dragon qui traverse, étincelles
  Le moniteur série (115200) affiche les images/seconde et le temps de rendu.

  Images : assets.h, généré par assets/png2assets.py à partir des PNG du dossier assets/.
  Broches : identiques à config.h du jeu (SCL 12, SDA 11, CS 10, DC 9, RES 8, BLK 7).
*/
#include <Arduino_GFX_Library.h>
#include "assets.h"

#define PIN_SCK 12
#define PIN_MOSI 11
#define PIN_CS 10
#define PIN_DC 9
#define PIN_RST 8
#define PIN_BL 7

Arduino_DataBus* bus = new Arduino_ESP32SPI(PIN_DC, PIN_CS, PIN_SCK, PIN_MOSI, GFX_NOT_DEFINED);
Arduino_GFX* panel = new Arduino_GC9A01(bus, PIN_RST, 0, true);
Arduino_Canvas* gfx = new Arduino_Canvas(240, 240, panel);   // tout se dessine ici, puis gfx->flush()

const int CX = 120, CY = 120;
const int SPANS = 10;                 // 10 questions = 10 travées
const int DECK_Y = 160;               // hauteur du tablier
const int X0 = 60, X1 = 180;          // entre les deux piles
const uint16_t C_BLUE = 0x2B57, C_RED = 0xC186, C_GOLD = 0xD4E8, C_WATER = 0x0B2C, C_WHITE = 0xFFFF, C_GREY = 0x8410;

enum Scene { ACCUEIL, QUESTION, REVELATION, FIN };
Scene scene = ACCUEIL;
uint32_t sceneStart = 0;
int spans = 0;                        // travées posées
bool lastWon = true;
int frames = 0; uint32_t fpsAt = 0, renderUs = 0;

static float easeOutBounce(float t) {
  if (t < 1 / 2.75f) return 7.5625f * t * t;
  if (t < 2 / 2.75f) { t -= 1.5f / 2.75f; return 7.5625f * t * t + 0.75f; }
  if (t < 2.5f / 2.75f) { t -= 2.25f / 2.75f; return 7.5625f * t * t + 0.9375f; }
  t -= 2.625f / 2.75f; return 7.5625f * t * t + 0.984375f;
}

// ---- calques -----------------------------------------------------------------
void drawBackground() { gfx->draw16bitRGBBitmap(0, 0, (uint16_t*)IMG_FOND_RIVES, IMG_FOND_RIVES_W, IMG_FOND_RIVES_H); }

void drawWater(float t) {             // vaguelettes : trois sinusoïdes qui défilent
  for (int i = 0; i < 3; i++) {
    int y0 = 182 + i * 16;
    for (int x = 0; x < 240; x += 2) {
      int y = y0 + (int)(3.0f * sinf(x * 0.08f + t * 2.0f + i));
      gfx->drawPixel(x, y, 0x3D9C);
      gfx->drawPixel(x + 1, y, 0x3D9C);
    }
  }
}

void drawBridge(int n, float t) {         // n travées posées, sur fond
  // tablier : on dessine de gauche à droite, chaque travée = tranche de 12 px du sprite
  int w = (X1 - X0) / SPANS;
  for (int i = 0; i < n; i++) {
    int x = X0 + i * w;
    for (int dx = 0; dx < w; dx++) {
      int sx = (i * w + dx) % IMG_TRAVEE_W;
      for (int dy = 0; dy < IMG_TRAVEE_H; dy++) {
        uint16_t c = pgm_read_word(&IMG_TRAVEE[dy * IMG_TRAVEE_W + sx]);
        if (c != IMG_KEY) gfx->drawPixel(x + dx, DECK_Y - 22 + dy, c);
      }
    }
  }
  // piles intermédiaires tous les 2 travées
  for (int i = 2; i < n; i += 2) gfx->fillRect(X0 + i * w - 2, DECK_Y, 4, 24, 0x4A69);
}

void drawFallingSpan(int i, float t, bool won) {   // t : 0..1
  int w = (X1 - X0) / SPANS;
  int x = X0 + i * w;
  int y;
  if (won) y = DECK_Y - 22 - 120 + (int)(120 * easeOutBounce(t));        // descend et rebondit
  else     y = DECK_Y - 22 + (int)(80 * t * t);                            // tombe dans l'eau
  for (int dx = 0; dx < w; dx++) {
    int sx = (i * w + dx) % IMG_TRAVEE_W;
    for (int dy = 0; dy < IMG_TRAVEE_H; dy++) {
      uint16_t c = pgm_read_word(&IMG_TRAVEE[dy * IMG_TRAVEE_W + sx]);
      if (c != IMG_KEY) gfx->drawPixel(x + dx, y + dy, c);
    }
  }
  if (!won && t > 0.6f) {   // ronds dans l'eau
    int r = (int)((t - 0.6f) * 60);
    gfx->drawEllipse(x + w / 2, DECK_Y + 30, r, r / 3, C_WHITE);
  }
}

void drawTimeRing(float frac) {           // anneau de temps : vert -> orange -> rouge
  uint16_t col = frac > 0.5f ? 0x07E0 : (frac > 0.25f ? 0xFD20 : 0xF800);
  gfx->drawArc(CX, CY, 119, 112, 0, 360, 0x2104);
  if (frac > 0) gfx->fillArc(CX, CY, 119, 112, -90, -90 + 360.0f * frac, col);
}

void centerText(const char* s, int y, int size, uint16_t color) {
  int w = strlen(s) * 6 * size;
  gfx->setTextSize(size); gfx->setTextColor(color); gfx->setCursor(CX - w / 2, y); gfx->print(s);
}

// ---- scènes -------------------------------------------------------------------
void sceneAccueil(float t) {
  drawBackground(); drawWater(t); drawBridge(spans, t);
  centerText("LePont-3", 60, 2, C_WHITE);
  centerText("192.168.4.1", 84, 1, C_GREY);
  int n = min(8, (int)(t * 2));         // les joueurs arrivent un par un sur le pourtour
  for (int i = 0; i < n; i++) {
    float a = -1.57f + i * 0.5f;
    gfx->fillCircle(CX + 104 * cosf(a), CY + 104 * sinf(a), 6, (i % 2) ? C_RED : C_BLUE);
  }
  char b[8]; snprintf(b, 8, "%d", n); centerText(b, 104, 4, C_GOLD);
}

void sceneQuestion(float t) {
  drawBackground(); drawWater(t); drawBridge(spans, t);
  float frac = 1.0f - t / 6.0f; if (frac < 0) frac = 0;
  drawTimeRing(frac);
  char b[8]; snprintf(b, 8, "%d", (int)(20 * frac + 0.99f)); centerText(b, 70, 6, C_WHITE);
  snprintf(b, 8, "Q %d", spans + 1); centerText(b, 124, 2, C_GREY);
}

void sceneRevelation(float t) {
  drawBackground(); drawWater(t); drawBridge(spans, t);
  float u = t / 1.6f; if (u > 1) u = 1;
  drawFallingSpan(spans, u, lastWon);
  if (u >= 1) centerText(lastWon ? "TRAVEE POSEE" : "TRAVEE RATEE", 60, 2, lastWon ? 0x07E0 : 0xF800);
}

void sceneFin(float t) {
  drawBackground(); drawWater(t); drawBridge(SPANS, t);
  // les lampadaires du pont s'allument
  for (int i = 0; i <= SPANS; i++) gfx->fillCircle(X0 + i * 12, DECK_Y - 26, 2, (int)(t * 6) % 2 ? C_GOLD : C_WHITE);
  int dx = (int)(-100 + t * 70) % 340 - 100;      // le dragon traverse
  gfx->draw16bitRGBBitmapWithTranColor(dx, 50 + (int)(6 * sinf(t * 3)), (uint16_t*)IMG_DRAGON, IMG_KEY, IMG_DRAGON_W, IMG_DRAGON_H);
  for (int i = 0; i < 12; i++) {                   // étincelles
    float a = t * 2 + i; int r = 60 + (int)(30 * sinf(t * 4 + i));
    gfx->drawPixel(CX + r * cosf(a), CY - 20 + r * sinf(a) / 2, C_GOLD);
  }
  centerText("VICTOIRE", 24, 2, C_GOLD);
}

void setup() {
  Serial.begin(115200); delay(300);
  if (PIN_BL >= 0) { pinMode(PIN_BL, OUTPUT); digitalWrite(PIN_BL, HIGH); }
  if (!gfx->begin(80000000)) Serial.println("[demo] gfx->begin a echoue");   // SPI 80 MHz ; si l'image est bruitee, essayer 40000000
  Serial.printf("[demo] canvas %dx%d, PSRAM libre %u octets, flash images %u octets\n", 240, 240, ESP.getFreePsram(), sizeof(IMG_FOND_RIVES) + sizeof(IMG_TRAVEE) + sizeof(IMG_DRAGON));
  sceneStart = millis(); fpsAt = millis();
}

void loop() {
  uint32_t t0 = micros();
  float t = (millis() - sceneStart) / 1000.0f;
  switch (scene) {
    case ACCUEIL:    sceneAccueil(t);    if (t > 5)   { scene = QUESTION;   sceneStart = millis(); } break;
    case QUESTION:   sceneQuestion(t);   if (t > 6.5) { scene = REVELATION; sceneStart = millis(); lastWon = (spans % 3) != 2; } break;
    case REVELATION: sceneRevelation(t); if (t > 3)   { if (lastWon) spans++; scene = (spans >= SPANS) ? FIN : QUESTION; sceneStart = millis(); } break;
    case FIN:        sceneFin(t);        if (t > 8)   { spans = 0; scene = ACCUEIL; sceneStart = millis(); } break;
  }
  gfx->flush();
  renderUs += micros() - t0; frames++;
  if (millis() - fpsAt >= 1000) {
    Serial.printf("[demo] scene %d  %d img/s  rendu+envoi %lu ms/img\n", (int)scene, frames, renderUs / frames / 1000);
    frames = 0; renderUs = 0; fpsAt = millis();
  }
}
