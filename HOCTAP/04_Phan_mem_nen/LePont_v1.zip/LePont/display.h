#pragma once
#include "config.h"
// =============================================================================
//  LE PONT · CẦU — l'écran de l'objet
//
//  Le jeu appelle ces six fonctions. L'écran n'affiche que l'ÉTAT du jeu
//  (compte à rebours, couleurs, scores, pont) : le texte des questions est sur
//  les téléphones et le grand écran, car la police embarquée n'a pas les accents
//  vietnamiens.
//
//  C'est ICI que ton groupe personnalise l'objet : couleurs, formes, animations,
//  anneau LED… Les prompts de vibe coding du soir 2 travaillent sur ce fichier.
// =============================================================================

void displayBegin();
void displayLobby(const char* ssid, int nPlayers);
void displayQuestion(int index, int total, int secLeft, int secTotal);
void displayReveal(bool spanWon, int nCorrect, int nAnswers);
void displayScores(const int* teamScores, int nTeams, float bridgeProgress);
void displayEnd(int winnerTeam, const int* teamScores, int nTeams);

#if DISPLAY_TYPE == 0
// ------------------------- Aucun écran : moniteur série -----------------------
void displayBegin() { Serial.println("[ecran] aucun ecran (DISPLAY_TYPE 0) : etats affiches ici"); }
void displayLobby(const char* ssid, int n) { Serial.printf("[ecran] SALON  %s  %d joueur(s)\n", ssid, n); }
void displayQuestion(int i, int t, int left, int tot) { Serial.printf("[ecran] Q %d/%d  %2d s\n", i + 1, t, left); }
void displayReveal(bool won, int c, int a) { Serial.printf("[ecran] %s  %d/%d justes\n", won ? "TRAVEE POSEE" : "travee ratee", c, a); }
void displayScores(const int* s, int n, float p) {
  Serial.printf("[ecran] pont %d%%  scores :", (int)(p * 100));
  for (int t = 0; t < n; t++) Serial.printf(" E%d=%d", t + 1, s[t]);
  Serial.println();
}
void displayEnd(int w, const int* s, int n) { Serial.printf("[ecran] FIN  victoire equipe %d (%d pts)\n", w + 1, s[w]); }

#else
// ------------------- Écran SPI via « GFX Library for Arduino » ----------------
#include <Arduino_GFX_Library.h>

static Arduino_DataBus* bus = new Arduino_ESP32SPI(PIN_DC, PIN_CS, PIN_SCK, PIN_MOSI, GFX_NOT_DEFINED);
#if DISPLAY_TYPE == 1
// ST7789 1.3" 240x240 : si l'image est décalée, essaie (…, 240, 240, 0, 80, 0, 0) ou une autre rotation
static Arduino_GFX* gfx = new Arduino_ST7789(bus, PIN_RST, 0 /*rotation*/, true /*IPS*/, 240, 240, 0, 0, 0, 80);
#else
static Arduino_GFX* gfx = new Arduino_GC9A01(bus, PIN_RST, 0 /*rotation*/, true /*IPS*/);
#endif

static const int CX = 120, CY = 120;   // centre de l'écran 240x240

static uint16_t teamColor(int t) {
  static const uint16_t c[4] = { 0x2B57 /*bleu*/, 0xC186 /*rouge*/, 0x2C2B /*vert*/, 0xB3C3 /*ocre*/ };
  return c[t & 3];
}
// Texte centré horizontalement (police de base 6x8, agrandie par « size »)
static void centerText(const char* s, int y, int size, uint16_t color) {
  int w = strlen(s) * 6 * size;
  gfx->setTextSize(size);
  gfx->setTextColor(color);
  gfx->setCursor(CX - w / 2, y);
  gfx->print(s);
}

void displayBegin() {
  if (PIN_BL >= 0) { pinMode(PIN_BL, OUTPUT); digitalWrite(PIN_BL, HIGH); }
  gfx->begin();
  gfx->fillScreen(BLACK);
  centerText("LE PONT", 92, 3, WHITE);
  centerText("CAU", 126, 3, ORANGE);
}

void displayLobby(const char* ssid, int n) {
  gfx->fillScreen(BLACK);
  gfx->drawCircle(CX, CY, 116, DARKGREY);
  centerText("WI-FI", 52, 2, LIGHTGREY);
  centerText(ssid, 78, 2, WHITE);
  centerText("192.168.4.1", 104, 1, LIGHTGREY);
  char buf[16];
  snprintf(buf, sizeof(buf), "%d", n);
  centerText(buf, 128, 5, ORANGE);
  centerText(n > 1 ? "joueurs" : "joueur", 178, 2, LIGHTGREY);
}

void displayQuestion(int i, int t, int left, int tot) {
  gfx->fillScreen(BLACK);
  // Anneau de compte à rebours : plein au départ, se vide avec le temps
  float frac = tot > 0 ? (float)left / tot : 0;
  uint16_t col = frac > 0.5f ? GREEN : (frac > 0.25f ? ORANGE : RED);
  if (frac > 0) gfx->fillArc(CX, CY, 118, 104, 0, 360.0f * frac, col);
  gfx->drawCircle(CX, CY, 104, DARKGREY);
  char buf[16];
  snprintf(buf, sizeof(buf), "%d", left);
  centerText(buf, 82, 7, WHITE);
  snprintf(buf, sizeof(buf), "Q %d/%d", i + 1, t);
  centerText(buf, 150, 2, LIGHTGREY);
}

void displayReveal(bool won, int c, int a) {
  gfx->fillScreen(won ? 0x0320 : 0x6000);   // vert sombre / rouge sombre
  centerText(won ? "TRAVEE" : "TRAVEE", 76, 3, WHITE);
  centerText(won ? "POSEE !" : "RATEE", 108, 3, WHITE);
  char buf[16];
  snprintf(buf, sizeof(buf), "%d/%d", c, a);
  centerText(buf, 150, 4, WHITE);
}

void displayScores(const int* s, int n, float p) {
  gfx->fillScreen(BLACK);
  // Le pont : un arc qui se complète de gauche à droite, au-dessus des scores
  gfx->drawArc(CX, CY, 118, 102, 180, 360, DARKGREY);
  if (p > 0) gfx->fillArc(CX, CY, 118, 102, 180, 180 + 180.0f * p, ORANGE);
  int y = 92;
  for (int t = 0; t < n && t < 4; t++) {
    char buf[16];
    snprintf(buf, sizeof(buf), "%d", s[t]);
    gfx->fillCircle(66, y + 10, 9, teamColor(t));
    gfx->setTextSize(3); gfx->setTextColor(WHITE); gfx->setCursor(86, y); gfx->print(buf);
    y += 34;
  }
  char pb[8];
  snprintf(pb, sizeof(pb), "%d%%", (int)(p * 100));
  centerText(pb, 50, 2, ORANGE);
}

void displayEnd(int w, const int* s, int n) {
  gfx->fillScreen(teamColor(w));
  centerText("VICTOIRE", 72, 3, WHITE);
  char buf[16];
  snprintf(buf, sizeof(buf), "EQUIPE %d", w + 1);
  centerText(buf, 108, 3, WHITE);
  snprintf(buf, sizeof(buf), "%d pts", s[w]);
  centerText(buf, 148, 3, WHITE);
}
#endif
