/*
  =============================================================================
   LE PONT · CẦU — jeu de questions France–Vietnam
   ESP32-S3 + smartphones des joueurs (hotspot Wi-Fi) + écran rond en option
   Atelier PFIEV × DUT Maker Innovation Space — Da Nang, oct.–nov. 2026
   Licence libre (MIT) : réutilise, adapte, partage, dis d'où ça vient.
  =============================================================================

  COMMENT ÇA MARCHE
   1. L'objet crée un Wi-Fi « LePont-N » (N = ton groupe) avec un portail captif.
   2. Les téléphones s'y connectent : la page du jeu s'ouvre (http://192.168.4.1).
   3. Un ordinateur sur le même Wi-Fi ouvre http://192.168.4.1/host : c'est le
      grand écran (projecteur) et la télécommande (Lancer / Suivante / Reset).
   4. Chaque question : les téléphones répondent, l'objet compte, révèle,
      distribue les points. Si au moins la moitié des joueurs a juste, une
      travée du pont est posée. Une partie = QUESTIONS_PER_GAME travées.
   5. http://192.168.4.1/admin : changer les questions sans reflasher.

  FICHIERS
   config.h      numéro de groupe, écran, broches, équipes
   questions.h   la base de questions (JSON)
   web_player.h  page des joueurs (téléphones)
   web_host.h    page grand écran + télécommande
   web_admin.h   page de modification des questions
   display.h     l'écran de l'objet — À PERSONNALISER par ton groupe

  BIBLIOTHÈQUES (Croquis → Inclure une bibliothèque → Gérer les bibliothèques)
   ESP Async WebServer (ESP32Async) + Async TCP · ArduinoJson 7 · GFX Library for Arduino

  CARTE (menu Outils) : ESP32S3 Dev Module · USB CDC On Boot: Enabled ·
   Flash Size: 16MB · PSRAM: OPI PSRAM · Partition: Huge APP (3MB No OTA/1MB SPIFFS)

  PROTOCOLE WEBSOCKET (JSON) — utile pour vibe coder de nouvelles manches
   téléphone → objet : {"t":"join","name":"Linh","team":0}   {"t":"answer","a":2}
   grand écran → objet : {"t":"hello","role":"host"}   {"t":"host","cmd":"start|next|reveal|reset"}
   objet → tous : config · lobby · question · tick · reveal · end · reset
   objet → un joueur : joined · you · full
*/

#include <WiFi.h>
#include <DNSServer.h>
#include <AsyncTCP.h>
#include <ESPAsyncWebServer.h>
#include <ArduinoJson.h>
#include "config.h"
#include "questions.h"
#include "web_player.h"
#include "web_host.h"
#include "web_admin.h"
#include "display.h"

// ----------------------------------------------------------------- réseau ----
DNSServer dns;
AsyncWebServer server(80);
AsyncWebSocket ws("/ws");
char ssid[16];

// ---------------------------------------------------------------- joueurs ----
struct Player {
  uint32_t id;        // identifiant de la connexion WebSocket
  char name[20];
  uint8_t team;
  int score;
  int answer;         // -1 = pas encore répondu
  uint32_t answerMs;
  bool active;        // false = déconnecté (la place et le score sont gardés)
};
Player players[MAX_PLAYERS];

// -------------------------------------------------------------------- jeu ----
enum State { LOBBY, QUESTION, REVEAL, END };
State state = LOBBY;
JsonDocument qdoc;              // toutes les questions jouables (parsées une fois)
int qCount = 0;                 // nombre de questions jouables
int order[64];                  // ordre de tirage de la partie
int qTotal = QUESTIONS_PER_GAME;
int qIndex = -1;                // position dans la partie
uint32_t qStart = 0;            // millis() au début de la question
int lastTick = -1;
uint32_t revealAt = 0;
bool scoresShown = false;
int teamScore[4] = {0, 0, 0, 0};
int spans = 0;                  // travées du pont posées

// ------------------------------------------------------------- utilitaires ----
Player* findPlayer(uint32_t id) {
  for (auto& p : players) if (p.active && p.id == id) return &p;
  return nullptr;
}
int activePlayers() { int n = 0; for (auto& p : players) if (p.active) n++; return n; }
int answersCount()  { int n = 0; for (auto& p : players) if (p.active && p.answer >= 0) n++; return n; }
JsonObject currentQ() { return qdoc[order[qIndex]].as<JsonObject>(); }

void loadQuestions(const char* json) {
  JsonDocument d;
  DeserializationError e = deserializeJson(d, json);
  if (e) { Serial.printf("[questions] JSON invalide : %s\n", e.c_str()); return; }
  qdoc.clear();
  JsonArray out = qdoc.to<JsonArray>();
  for (JsonObject q : d.as<JsonArray>()) {
    JsonArray o = q["o"].as<JsonArray>();
    int r = q["r"] | -1;
    if (o.size() == 4 && r >= 0 && r <= 3) out.add(q);   // v1 : QCM à 4 choix (les estimations = exercice du soir 2)
  }
  qCount = out.size();
  Serial.printf("[questions] %d questions chargees\n", qCount);
}

void shuffleOrder() {
  int n = qCount > 64 ? 64 : qCount;
  for (int i = 0; i < n; i++) order[i] = i;
  for (int i = n - 1; i > 0; i--) { int j = random(i + 1); int t = order[i]; order[i] = order[j]; order[j] = t; }
  qTotal = (QUESTIONS_PER_GAME < n) ? QUESTIONS_PER_GAME : n;
}

void sendTo(AsyncWebSocketClient* c, JsonDocument& d) { String s; serializeJson(d, s); c->text(s); }
void broadcast(JsonDocument& d) { String s; serializeJson(d, s); ws.textAll(s); }
void addScores(JsonDocument& d) {
  JsonArray a = d["scores"].to<JsonArray>();
  for (int t = 0; t < TEAM_COUNT; t++) a.add(teamScore[t]);
}

void sendConfig(AsyncWebSocketClient* c) {
  JsonDocument d;
  d["t"] = "config"; d["ssid"] = ssid; d["total"] = qTotal; d["sec"] = QUESTION_SECONDS;
  JsonArray teams = d["teams"].to<JsonArray>();
  for (int t = 0; t < TEAM_COUNT; t++) { JsonObject o = teams.add<JsonObject>(); o["n"] = TEAM_NAMES[t]; o["c"] = TEAM_COLORS[t]; }
  sendTo(c, d);
}
void lobbyDoc(JsonDocument& d) {
  d["t"] = "lobby";
  JsonArray a = d["players"].to<JsonArray>();
  for (auto& p : players) if (p.active) { JsonObject o = a.add<JsonObject>(); o["n"] = p.name; o["team"] = p.team; o["s"] = p.score; }
  addScores(d);
}
void broadcastLobby() { JsonDocument d; lobbyDoc(d); broadcast(d); displayLobby(ssid, activePlayers()); }

void questionDoc(JsonDocument& d) {
  JsonObject q = currentQ();
  d["t"] = "question"; d["i"] = qIndex; d["n"] = qTotal; d["sec"] = QUESTION_SECONDS;
  d["cat"] = q["cat"]; d["fr"] = q["fr"]; d["vi"] = q["vi"]; d["o"] = q["o"];
}

// ------------------------------------------------------- déroulé du jeu ----
void endGame();

void startQuestion() {
  qIndex++;
  if (qIndex >= qTotal) { endGame(); return; }
  for (auto& p : players) { p.answer = -1; p.answerMs = 0; }
  state = QUESTION; qStart = millis(); lastTick = -1;
  JsonDocument d; questionDoc(d); broadcast(d);
  displayQuestion(qIndex, qTotal, QUESTION_SECONDS, QUESTION_SECONDS);
  Serial.printf("[jeu] question %d/%d\n", qIndex + 1, qTotal);
}

void reveal() {
  if (state != QUESTION) return;
  state = REVEAL; revealAt = millis(); scoresShown = false;
  JsonObject q = currentQ();
  int r = q["r"] | 0;
  int nCorrect = 0, nAns = 0;
  for (auto& p : players) {
    if (!p.active) continue;
    int pts = 0;
    if (p.answer >= 0) {
      nAns++;
      if (p.answer == r) {
        nCorrect++;
        float speed = 1.0f - (float)(p.answerMs - qStart) / (QUESTION_SECONDS * 1000.0f);   // 1 = immédiat, 0 = dernière seconde
        if (speed < 0) speed = 0;
        pts = 100 + (int)(50 * speed);
        p.score += pts; teamScore[p.team] += pts;
      }
    }
    JsonDocument y; y["t"] = "you"; y["ok"] = (p.answer == r); y["pts"] = pts;
    AsyncWebSocketClient* c = ws.client(p.id);
    if (c) sendTo(c, y);
  }
  bool won = nAns > 0 && nCorrect * 2 >= nAns;     // travée posée si au moins la moitié a juste
  if (won) spans++;
  JsonDocument d;
  d["t"] = "reveal"; d["r"] = r; d["pfr"] = q["pfr"]; d["pvi"] = q["pvi"];
  d["won"] = won; d["spans"] = spans; d["nc"] = nCorrect; d["na"] = nAns; addScores(d);
  broadcast(d);
  displayReveal(won, nCorrect, nAns);
  Serial.printf("[jeu] reponse %c  %d/%d justes  pont %d/%d\n", 'A' + r, nCorrect, nAns, spans, qTotal);
}

void endGame() {
  state = END;
  int w = 0;
  for (int t = 1; t < TEAM_COUNT; t++) if (teamScore[t] > teamScore[w]) w = t;
  JsonDocument d; d["t"] = "end"; d["spans"] = spans; d["winner"] = w; addScores(d); broadcast(d);
  displayEnd(w, teamScore, TEAM_COUNT);
  Serial.printf("[jeu] fin  victoire equipe %d\n", w + 1);
}

void resetGame(bool keepPlayers) {
  state = LOBBY; qIndex = -1; spans = 0;
  for (int t = 0; t < 4; t++) teamScore[t] = 0;
  for (auto& p : players) { p.score = 0; p.answer = -1; if (!keepPlayers) { p.active = false; p.name[0] = 0; } }
  shuffleOrder();
  JsonDocument d; d["t"] = "reset"; broadcast(d);
  broadcastLobby();
  Serial.println("[jeu] reset");
}

// ------------------------------------------------------------ WebSocket ----
void onWsMessage(AsyncWebSocketClient* c, uint8_t* data, size_t len) {
  JsonDocument m;
  if (deserializeJson(m, data, len)) return;
  const char* t = m["t"] | "";

  if (!strcmp(t, "hello")) {                       // grand écran / télécommande
    sendConfig(c);
    if (state == LOBBY) { JsonDocument d; lobbyDoc(d); sendTo(c, d); }
    else if (state == QUESTION || state == REVEAL) { JsonDocument d; questionDoc(d); sendTo(c, d); }
  }
  else if (!strcmp(t, "join")) {
    const char* name = m["name"] | "?";
    Player* p = findPlayer(c->id());
    if (!p) for (auto& x : players) if (!x.active && x.name[0] && !strcmp(x.name, name)) { p = &x; break; }   // reconnexion : même prénom
    if (!p) for (auto& x : players) if (!x.active) { p = &x; p->score = 0; break; }
    if (!p) { JsonDocument d; d["t"] = "full"; sendTo(c, d); return; }
    p->active = true; p->id = c->id();
    strlcpy(p->name, name, sizeof(p->name));
    int team = m["team"] | 0;
    p->team = constrain(team, 0, TEAM_COUNT - 1);
    if (state != QUESTION) p->answer = -1;
    JsonDocument d; d["t"] = "joined"; d["id"] = c->id(); sendTo(c, d);
    if (state == LOBBY) broadcastLobby();
    else if (state == QUESTION) { JsonDocument q; questionDoc(q); sendTo(c, q); }
    Serial.printf("[joueur] %s rejoint l'equipe %d (%d connectes)\n", p->name, p->team + 1, activePlayers());
  }
  else if (!strcmp(t, "answer")) {
    if (state != QUESTION) return;
    Player* p = findPlayer(c->id());
    if (!p || p->answer >= 0) return;
    int a = m["a"] | -1;
    if (a < 0 || a > 3) return;
    p->answer = a; p->answerMs = millis();
    if (answersCount() >= activePlayers()) reveal();   // tout le monde a répondu : on révèle sans attendre
  }
  else if (!strcmp(t, "host")) {
    const char* cmd = m["cmd"] | "";
    if (!strcmp(cmd, "start"))       { if (state == LOBBY) startQuestion(); }
    else if (!strcmp(cmd, "next"))   { if (state == QUESTION) reveal(); else if (state == REVEAL) startQuestion(); else if (state == END) resetGame(true); }
    else if (!strcmp(cmd, "reveal")) { reveal(); }
    else if (!strcmp(cmd, "reset"))  { resetGame(false); }
  }
}

void onWsEvent(AsyncWebSocket* s, AsyncWebSocketClient* c, AwsEventType type, void* arg, uint8_t* data, size_t len) {
  if (type == WS_EVT_CONNECT) {
    sendConfig(c);
  } else if (type == WS_EVT_DISCONNECT) {
    Player* p = findPlayer(c->id());
    if (p) { p->active = false; if (state == LOBBY) broadcastLobby(); }
  } else if (type == WS_EVT_DATA) {
    AwsFrameInfo* info = (AwsFrameInfo*)arg;
    if (info->final && info->index == 0 && info->len == len && info->opcode == WS_TEXT) onWsMessage(c, data, len);
  }
}

// --------------------------------------------------- serveur web + captif ----
void redirectHome(AsyncWebServerRequest* r) { r->redirect("http://192.168.4.1/"); }

void setupServer() {
  server.on("/",      HTTP_GET, [](AsyncWebServerRequest* r) { r->send(200, "text/html; charset=utf-8", PLAYER_HTML); });
  server.on("/host",  HTTP_GET, [](AsyncWebServerRequest* r) { r->send(200, "text/html; charset=utf-8", HOST_HTML); });
  server.on("/admin", HTTP_GET, [](AsyncWebServerRequest* r) { r->send(200, "text/html; charset=utf-8", ADMIN_HTML); });

  server.on("/api/questions", HTTP_GET, [](AsyncWebServerRequest* r) {
    String s; serializeJson(qdoc, s);
    r->send(200, "application/json; charset=utf-8", s);
  });
  server.on("/api/questions", HTTP_POST,
    [](AsyncWebServerRequest* r) {},
    NULL,
    [](AsyncWebServerRequest* r, uint8_t* data, size_t len, size_t index, size_t total) {
      static String body;
      if (index == 0) body = "";
      body.concat((const char*)data, len);
      if (index + len == total) {
        loadQuestions(body.c_str());
        body = "";
        if (state == LOBBY) shuffleOrder();
        r->send(200, "text/plain; charset=utf-8", String(qCount) + " questions chargees dans l'objet");
      }
    });
  server.on("/api/state", HTTP_GET, [](AsyncWebServerRequest* r) {
    JsonDocument d;
    d["ssid"] = ssid; d["state"] = (int)state; d["players"] = activePlayers(); d["question"] = qIndex;
    d["spans"] = spans; d["questions"] = qCount; d["heap"] = ESP.getFreeHeap(); d["clients"] = ws.count();
    String s; serializeJson(d, s);
    r->send(200, "application/json", s);
  });

  // Portail captif : les sondes des téléphones sont renvoyées vers la page du jeu
  server.on("/generate_204", HTTP_GET, redirectHome);          // Android
  server.on("/gen_204", HTTP_GET, redirectHome);
  server.on("/hotspot-detect.html", HTTP_GET, redirectHome);   // iPhone / Mac
  server.on("/library/test/success.html", HTTP_GET, redirectHome);
  server.on("/connecttest.txt", HTTP_GET, redirectHome);       // Windows
  server.on("/ncsi.txt", HTTP_GET, redirectHome);
  server.on("/fwlink", HTTP_GET, redirectHome);
  server.onNotFound(redirectHome);

  ws.onEvent(onWsEvent);
  server.addHandler(&ws);
  server.begin();
}

// ------------------------------------------------------------------ setup ----
void setup() {
  Serial.begin(115200);
  delay(300);
  Serial.println("\n=== LE PONT · CAU ===");

  snprintf(ssid, sizeof(ssid), "LePont-%d", GROUP_ID);
  for (auto& p : players) { p.active = false; p.name[0] = 0; p.score = 0; p.answer = -1; }
  loadQuestions(QUESTIONS_JSON);
  shuffleOrder();
  displayBegin();

  WiFi.mode(WIFI_AP);
  WiFi.softAPConfig(IPAddress(192, 168, 4, 1), IPAddress(192, 168, 4, 1), IPAddress(255, 255, 255, 0));
  uint8_t ch = WIFI_CHANNELS[(GROUP_ID - 1) % 7];
  int maxConn = MAX_PLAYERS + 2; if (maxConn > 10) maxConn = 10;
  bool ok = WiFi.softAP(ssid, strlen(WIFI_PASSWORD) >= 8 ? WIFI_PASSWORD : NULL, ch, 0, maxConn);
  Serial.printf("[wifi] %s  canal %d  %s  (%s)\n", ssid, ch, WiFi.softAPIP().toString().c_str(), ok ? "OK" : "ECHEC");

  dns.start(53, "*", WiFi.softAPIP());
  setupServer();
  displayLobby(ssid, 0);
  Serial.println("[http] joueurs : http://192.168.4.1/   grand ecran : /host   questions : /admin   etat : /api/state");
}

// ------------------------------------------------------------------- loop ----
void loop() {
  dns.processNextRequest();

  static uint32_t lastClean = 0;
  if (millis() - lastClean > 1000) { ws.cleanupClients(); lastClean = millis(); }

  if (state == QUESTION) {
    int left = QUESTION_SECONDS - (int)((millis() - qStart) / 1000);
    if (left < 0) left = 0;
    if (left != lastTick) {
      lastTick = left;
      JsonDocument d; d["t"] = "tick"; d["left"] = left; d["answers"] = answersCount(); broadcast(d);
      displayQuestion(qIndex, qTotal, left, QUESTION_SECONDS);
    }
    if (left == 0) reveal();
  }
  else if (state == REVEAL && !scoresShown && millis() - revealAt > 4000) {
    scoresShown = true;
    displayScores(teamScore, TEAM_COUNT, qTotal > 0 ? (float)spans / qTotal : 0);
  }
}
