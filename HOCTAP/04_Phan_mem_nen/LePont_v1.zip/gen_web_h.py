import sys, pathlib
base = pathlib.Path(sys.argv[1])
out = pathlib.Path(sys.argv[2])
pages = [("player.html", "web_player.h", "PLAYER_HTML", "page des joueurs (téléphones) — http://192.168.4.1/"),
         ("host.html", "web_host.h", "HOST_HTML", "page grand écran + télécommande — http://192.168.4.1/host"),
         ("admin.html", "web_admin.h", "ADMIN_HTML", "page de modification des questions — http://192.168.4.1/admin")]
for src, dst, name, desc in pages:
    html = (base / src).read_text(encoding="utf-8")
    assert ')html"' not in html, src
    txt = ("#pragma once\n"
           "// =============================================================================\n"
           f"//  LE PONT · CẦU — {desc}\n"
           f"//  Généré depuis web/{src} : modifie le .html puis relance gen_web_h.py,\n"
           "//  ou édite directement ci-dessous (c'est du HTML/JS ordinaire).\n"
           "// =============================================================================\n"
           f"const char {name}[] PROGMEM = R\"html(\n{html}\n)html\";\n")
    (out / dst).write_text(txt, encoding="utf-8")
    print(dst, len(html), "bytes")
