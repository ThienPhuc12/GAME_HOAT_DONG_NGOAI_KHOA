# Le Pont France – Vietnam · Cầu Pháp – Việt

Un jeu de questions-réponses interculturel posé au centre de la table : un petit objet (ESP32-S3 + écran rond)
crée son propre Wi-Fi, les joueurs répondent depuis leur smartphone, un grand écran montre le pont qui se construit
à chaque bonne réponse collective. Né à l'atelier **PFIEV × DUT Maker Innovation Space** (Da Nang, 2026),
conçu pour être reproduit et adapté n'importe où : un autre pays, une autre histoire partagée, une autre langue.

Licence : **MIT** pour le code, **CC BY-SA 4.0** pour les questions et la documentation.

## Comment ça marche

```
 téléphones des joueurs ──Wi-Fi « LePont-N »──┐
                                              ▼
                                      ┌───────────────┐
 ordinateur (grand écran) ──Wi-Fi────►│   ESP32-S3    │──SPI──► écran rond (état du jeu)
   http://192.168.4.1/host            │ serveur web + │
                                      │  WebSocket +  │
                                      │ machine à états│
                                      └───────────────┘
```

1. L'objet crée un point d'accès Wi-Fi avec portail captif ; les téléphones ouvrent `http://192.168.4.1`.
2. Le grand écran (`/host`) est aussi la télécommande : Lancer · Suivante · Révéler · Reset.
3. Chaque question : 20 s, réponses sur les téléphones, révélation en deux langues, points
   (100 + bonus de rapidité). Si au moins la moitié des joueurs a juste, **une travée du pont est posée**.
4. Une partie = 10 questions = 10 travées. Le pont est complet quand la salle a tout réussi ensemble.
5. `/admin` : coller de nouvelles questions sans reflasher ; `/api/state` : état de l'objet.

## Matériel (par objet)

- 1 × ESP32-S3 DevKitC-1 **N16R8** (16 Mo flash, 8 Mo PSRAM)
- 1 × écran SPI 240×240 : ST7789 1,3" (carré) ou GC9A01 1,28" (rond, tactile)
- 7 fils Dupont femelle-femelle, 1 câble USB-C de données, 1 powerbank
- Un boîtier modélisé et imprimé en 3D par le groupe

Câblage écran → ESP32-S3 : VCC→3V3 · GND→GND · SCL→12 · SDA→11 · CS→10 · DC→9 · RES→8 · BLK→7

## Fichiers

| Fichier | Rôle | Qui le modifie |
|---|---|---|
| `LePont/LePont.ino` | réseau, serveur, machine à états, scores | les curieux |
| `LePont/config.h` | numéro de groupe, écran, broches, équipes | **tout le monde, en premier** |
| `LePont/questions.h` | la base de questions (JSON) | **tout le monde** |
| `LePont/display.h` | l'écran de l'objet | **votre terrain de jeu** |
| `LePont/web_player.h` | page des téléphones | soir 2 |
| `LePont/web_host.h` | page grand écran | soir 2 |
| `LePont/web_admin.h` | page de modification des questions | rarement |
| `web/*.html` | sources des pages ; `gen_web_h.py` les régénère en `.h` | si vous préférez éditer du .html |
| `test/` | serveur de simulation (Python) pour tester les pages sans ESP32 | optionnel |

Installation : voir **GUIDE_INSTALLATION.md**.

## Protocole WebSocket (JSON) — pour vibe coder de nouvelles manches

Téléphone → objet : `{"t":"join","name":"Linh","team":0}` · `{"t":"answer","a":2}`
Grand écran → objet : `{"t":"hello","role":"host"}` · `{"t":"host","cmd":"start|next|reveal|reset"}`
Objet → tous : `config` (équipes, ssid) · `lobby` (joueurs, scores) · `question` (i, n, fr, vi, o, sec) ·
`tick` (left, answers) · `reveal` (r, pfr, pvi, won, spans, scores) · `end` (winner, spans, scores) · `reset`
Objet → un joueur : `joined` · `you` (ok, pts) · `full`

## Les trois soirées

**Soir 1 — ça marche.** Installer, flasher la base, jouer une partie avec les 10 questions du groupe,
lire `LePont.ino` ensemble, câbler l'écran et passer `DISPLAY_TYPE` à 1.

**Soir 2 — c'est le vôtre.** Vibe coding : une nouvelle manche (estimation, mot caché, vrai/faux),
un nouvel écran dans `display.h`, de nouvelles règles de points. Modéliser le boîtier.

**Soir 3 — c'est fini et partagé.** Imprimer, assembler, jouer, documenter, démontrer.

## Prompts de départ pour l'IA (copier-coller avec le fichier concerné)

- « Voici `display.h`. Remplace l'écran de question par un cadran : anneau de compte à rebours qui change
  de couleur, numéro de question au centre, et une bordure aux couleurs de l'équipe qui mène. Garde les
  mêmes six fonctions et la bibliothèque Arduino_GFX. »
- « Voici `LePont.ino` et `questions.h`. Ajoute un type de question `num` (estimation) : les joueurs tapent
  un nombre, le plus proche de `num` gagne 150 points, les autres 0. Ajoute le champ de saisie dans
  `web_player.h` et l'affichage des estimations dans `web_host.h`. »
- « Voici `web_host.h`. Dessine le pont comme une arche entre deux rives avec un dragon qui s'allume
  quand toutes les travées sont posées. SVG pur, pas de bibliothèque externe. »
- « Voici `config.h` et `LePont.ino`. Passe à 4 équipes avec un code couleur, et affiche le classement
  des équipes à la fin. »

## Documentation open source attendue de chaque groupe

Un dossier avec : le code modifié, les fichiers 3D (STL + source), une photo du câblage, vos questions
(FR/VI), une vidéo de 30 s du jeu en action, et un `README` qui explique comment reproduire votre objet
et ce que vous changeriez pour un autre pays. Publiez-le sous licence libre.
