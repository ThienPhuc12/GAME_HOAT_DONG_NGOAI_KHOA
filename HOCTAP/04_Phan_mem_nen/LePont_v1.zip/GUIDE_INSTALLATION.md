# Le Pont · Cầu — Guide d'installation (à faire AVANT la première soirée)

Atelier PFIEV × DUT Maker Innovation Space · Un ordinateur par groupe suffit.
Comptez 20 à 30 minutes, surtout pour le téléchargement du support ESP32 (environ 1 Go).

## 1. Installer Arduino IDE 2

Téléchargez Arduino IDE 2 sur https://www.arduino.cc/en/software (Windows, macOS ou Linux) et installez-le.

## 2. Ajouter le support des cartes ESP32

1. **Fichier → Préférences** (sur Mac : Arduino IDE → Réglages).
2. Dans « URL de gestionnaire de cartes supplémentaires », collez :
   `https://espressif.github.io/arduino-esp32/package_esp32_index.json`
3. **Outils → Type de carte → Gestionnaire de cartes**, cherchez `esp32`,
   installez **esp32 by Espressif Systems** (version 3.x). Patientez jusqu'à la fin.

## 3. Installer les bibliothèques

**Croquis → Inclure une bibliothèque → Gérer les bibliothèques**, puis cherchez et installez :

| Bibliothèque | Auteur | Rôle |
|---|---|---|
| **ESP Async WebServer** | ESP32Async | serveur web + WebSocket (acceptez d'installer **Async TCP** avec) |
| **ArduinoJson** (7.x) | Benoit Blanchon | questions et messages du jeu |
| **GFX Library for Arduino** | Moon On Our Nation | l'écran de l'objet |

## 4. Brancher la carte et la configurer

Branchez l'ESP32-S3 avec un câble USB-C **de données** (un câble de charge seule ne fonctionne pas).
Si la carte a deux prises USB-C, utilisez celle marquée **COM** ou **UART**.

Menu **Outils** :

| Réglage | Valeur |
|---|---|
| Type de carte | **ESP32S3 Dev Module** |
| Port | le port COMx / /dev/… qui apparaît quand la carte est branchée |
| USB CDC On Boot | **Enabled** |
| Flash Size | **16MB (128Mb)** |
| PSRAM | **OPI PSRAM** |
| Partition Scheme | **Huge APP (3MB No OTA/1MB SPIFFS)** |
| Upload Speed | 921600 |

Aucun port n'apparaît ? Installez le pilote USB de la carte : **CH343** (le plus courant) ou **CP210x**,
selon la petite puce près de la prise USB. Débranchez et rebranchez ensuite.

## 5. Le test qui valide tout

**Fichier → Exemples → WiFi → WiFiScan**, bouton **Téléverser** (flèche →), puis **Outils → Moniteur série** à **115200 baud**.
Si la liste des réseaux Wi-Fi s'affiche, votre chaîne complète fonctionne.

Si le téléversement échoue avec « Failed to connect » : maintenez le bouton **BOOT** de la carte,
appuyez une fois sur **RESET**, relâchez BOOT, puis relancez le téléversement.

## 6. Ouvrir le jeu

1. Dézippez le dossier **LePont** et ouvrez **LePont.ino** (les autres fichiers s'ouvrent en onglets).
2. Dans l'onglet **config.h**, mettez votre numéro de groupe dans `GROUP_ID` (1 à 7)
   et laissez `DISPLAY_TYPE 0` tant que l'écran n'est pas câblé.
3. Téléversez. Ouvrez le moniteur série : vous devez voir `[wifi] LePont-N … OK`.
4. Sur votre téléphone : Wi-Fi **LePont-N** (sans mot de passe). La page du jeu s'ouvre toute seule ;
   sinon ouvrez **http://192.168.4.1** dans le navigateur.
5. Sur l'ordinateur, connecté au même Wi-Fi : **http://192.168.4.1/host** = grand écran + télécommande.
   Appuyez sur **Lancer**.

À apporter le premier soir : cet ordinateur prêt, une powerbank chargée avec son câble, vos smartphones,
et 10 questions France–Vietnam écrites par le groupe (en français et en vietnamien).
