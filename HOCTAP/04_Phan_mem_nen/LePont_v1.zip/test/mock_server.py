"""Serveur de test : imite l'ESP32 (HTTP + WebSocket, même protocole) pour vérifier les pages.
Lance : python3 mock_server.py  -> http://localhost:8080/ et /host
"""
import asyncio, json, pathlib, random, sys, threading, http.server, socketserver
import websockets

WEB = pathlib.Path(__file__).resolve().parent.parent / "web"
QUESTIONS = json.load(open(pathlib.Path(__file__).resolve().parent.parent / "test" / "q.json", encoding="utf-8"))
TEAMS = [{"n": "Rive France", "c": "#2b6cb0"}, {"n": "Rive Vietnam", "c": "#c53030"}]
SEC = 5
TOTAL = 3

class G:
    state = "lobby"; players = {}; qi = -1; order = []; spans = 0; scores = [0, 0]; answers = {}; qstart = 0
    clients = set(); tick_task = None

def q():
    return QUESTIONS[G.order[G.qi]]

async def send(ws, d):
    try: await ws.send(json.dumps(d, ensure_ascii=False))
    except Exception: pass

async def broadcast(d):
    for c in list(G.clients): await send(c, d)

def lobby_doc():
    return {"t": "lobby", "players": [{"n": p["n"], "team": p["team"], "s": p["s"]} for p in G.players.values()], "scores": G.scores}

def question_doc():
    x = q(); return {"t": "question", "i": G.qi, "n": TOTAL, "sec": SEC, "cat": x["cat"], "fr": x["fr"], "vi": x["vi"], "o": x["o"]}

async def start_question():
    G.qi += 1
    if G.qi >= TOTAL: return await end_game()
    G.state = "q"; G.answers = {}; G.qstart = asyncio.get_event_loop().time()
    await broadcast(question_doc())
    if G.tick_task: G.tick_task.cancel()
    G.tick_task = asyncio.create_task(ticker())

async def ticker():
    for left in range(SEC - 1, -1, -1):
        await asyncio.sleep(1)
        await broadcast({"t": "tick", "left": left, "answers": len(G.answers)})
    await reveal()

async def reveal():
    if G.state != "q": return
    G.state = "rev"
    if G.tick_task: G.tick_task.cancel(); G.tick_task = None
    x = q(); r = x["r"]; nc = 0; na = 0
    for ws, p in G.players.items():
        a = G.answers.get(ws, -1); pts = 0
        if a >= 0:
            na += 1
            if a == r: nc += 1; pts = 120; p["s"] += pts; G.scores[p["team"]] += pts
        await send(ws, {"t": "you", "ok": a == r, "pts": pts})
    won = na > 0 and nc * 2 >= na
    if won: G.spans += 1
    await broadcast({"t": "reveal", "r": r, "pfr": x["pfr"], "pvi": x["pvi"], "won": won, "spans": G.spans, "nc": nc, "na": na, "scores": G.scores})

async def end_game():
    G.state = "end"
    w = 0 if G.scores[0] >= G.scores[1] else 1
    await broadcast({"t": "end", "spans": G.spans, "winner": w, "scores": G.scores})

async def reset(keep):
    G.state = "lobby"; G.qi = -1; G.spans = 0; G.scores = [0, 0]
    for p in G.players.values(): p["s"] = 0
    if not keep: G.players = {}
    G.order = list(range(len(QUESTIONS))); random.shuffle(G.order)
    await broadcast({"t": "reset"}); await broadcast(lobby_doc())

async def handler(ws):
    G.clients.add(ws)
    await send(ws, {"t": "config", "ssid": "LePont-1", "total": TOTAL, "sec": SEC, "teams": TEAMS})
    try:
        async for raw in ws:
            m = json.loads(raw); t = m.get("t")
            if t == "hello":
                if G.state == "lobby": await send(ws, lobby_doc())
                elif G.state in ("q", "rev"): await send(ws, question_doc())
            elif t == "join":
                G.players[ws] = {"n": m.get("name", "?"), "team": int(m.get("team", 0)), "s": 0}
                await send(ws, {"t": "joined", "id": id(ws)})
                if G.state == "lobby": await broadcast(lobby_doc())
                elif G.state == "q": await send(ws, question_doc())
            elif t == "answer":
                if G.state == "q" and ws in G.players and ws not in G.answers:
                    G.answers[ws] = int(m.get("a", -1))
                    if len(G.answers) >= len(G.players): await reveal()
            elif t == "host":
                c = m.get("cmd")
                if c == "start" and G.state == "lobby": await start_question()
                elif c == "next":
                    if G.state == "q": await reveal()
                    elif G.state == "rev": await start_question()
                    elif G.state == "end": await reset(True)
                elif c == "reveal": await reveal()
                elif c == "reset": await reset(False)
    finally:
        G.clients.discard(ws)
        if ws in G.players:
            del G.players[ws]
            if G.state == "lobby": await broadcast(lobby_doc())

class H(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *a, **k): super().__init__(*a, directory=str(WEB), **k)
    def do_GET(self):
        if self.path == "/": self.path = "/player.html"
        elif self.path == "/host": self.path = "/host.html"
        elif self.path == "/admin": self.path = "/admin.html"
        elif self.path == "/api/questions":
            b = json.dumps(QUESTIONS, ensure_ascii=False).encode(); self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8"); self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b); return
        return super().do_GET()
    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0)); body = self.rfile.read(n)
        try: k = len(json.loads(body)); msg = f"{k} questions chargees dans l'objet"; code = 200
        except Exception as e: msg = f"JSON invalide: {e}"; code = 400
        b = msg.encode(); self.send_response(code); self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def log_message(self, *a): pass

async def main():
    G.order = list(range(len(QUESTIONS))); random.shuffle(G.order)
    httpd = socketserver.ThreadingTCPServer(("127.0.0.1", 8080), H); httpd.daemon_threads = True
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    async with websockets.serve(handler, "127.0.0.1", 8081):
        print("mock ready: http://127.0.0.1:8080/  ws://127.0.0.1:8081", flush=True)
        await asyncio.Future()

asyncio.run(main())
