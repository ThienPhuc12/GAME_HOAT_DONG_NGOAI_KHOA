import asyncio, json, pathlib, subprocess, sys, time
from playwright.async_api import async_playwright

HERE = pathlib.Path(__file__).resolve().parent
OUT = HERE / "shots"; OUT.mkdir(exist_ok=True)
REWRITE = "(() => { const O = window.WebSocket; window.WebSocket = function(u, p){ return new O(u.replace(':8080/ws', ':8081'), p); }; window.WebSocket.prototype = O.prototype; })();"

async def main():
    srv = subprocess.Popen([sys.executable, str(HERE / "mock_server.py")], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    time.sleep(1.5)
    errors = []
    try:
        async with async_playwright() as pw:
            b = await pw.chromium.launch()
            def mkctx(w, h): return b.new_context(viewport={"width": w, "height": h}, device_scale_factor=1)
            host_ctx = await mkctx(1280, 720); p1_ctx = await mkctx(390, 780); p2_ctx = await mkctx(390, 780)
            pages = []
            for ctx, path in ((host_ctx, "/host"), (p1_ctx, "/"), (p2_ctx, "/")):
                pg = await ctx.new_page()
                pg.on("pageerror", lambda e, path=path: errors.append(f"{path}: {e}"))
                pg.on("console", lambda m, path=path: errors.append(f"{path}: console.{m.type}: {m.text}") if m.type == "error" else None)
                await pg.add_init_script(REWRITE)
                await pg.goto(f"http://127.0.0.1:8080{path}")
                pages.append(pg)
            host, p1, p2 = pages
            await asyncio.sleep(0.8)
            assert "LePont-1" in await host.text_content("#ssid2"), "host did not get config"
            # joueurs
            await p1.fill("#name", "Linh"); await p1.click("#teams .team:nth-child(1)"); await p1.click("button.primary")
            await p2.fill("#name", "Yassine"); await p2.click("#teams .team:nth-child(2)"); await p2.click("button.primary")
            await asyncio.sleep(0.6)
            assert "2 joueurs" in await host.text_content("#cnt"), await host.text_content("#cnt")
            assert not (await p1.locator("#s-lobby").get_attribute("class") or "").count("hide"), "p1 not in lobby"
            await host.screenshot(path=OUT / "host_lobby.png"); await p1.screenshot(path=OUT / "player_lobby.png")
            # lancer
            await host.click("#btn"); await asyncio.sleep(0.6)
            assert "Question 1" in await host.text_content("#qn")
            assert "Question 1/3" in await p1.text_content("#qn")
            await host.screenshot(path=OUT / "host_question.png"); await p1.screenshot(path=OUT / "player_question.png")
            # reponses : tout le monde repond -> reveal immediat
            await p1.click("#o0"); await asyncio.sleep(0.3); await p2.click("#o1"); await asyncio.sleep(0.8)
            v1 = await p1.text_content("#verdict"); v2 = await p2.text_content("#verdict")
            assert v1 and v2, "no reveal on players"
            assert not (await host.locator("#pfr").get_attribute("class") or "").count("hide"), "host reveal hidden"
            await host.screenshot(path=OUT / "host_reveal.png"); await p1.screenshot(path=OUT / "player_reveal.png")
            # question 2 : laisser le temps expirer (5 s)
            await host.click("#btn"); await asyncio.sleep(0.5)
            assert "Question 2" in await host.text_content("#qn")
            await p1.click("#o2"); await asyncio.sleep(6.0)
            assert "✓" in await host.text_content("#timer"), "timer did not expire into reveal"
            # question 3 puis fin
            await host.click("#btn"); await asyncio.sleep(0.5); await p1.click("#o0"); await p2.click("#o0"); await asyncio.sleep(0.8)
            await host.click("#btn"); await asyncio.sleep(0.8)
            assert "Victoire" in await host.text_content("#winner"), await host.text_content("#winner")
            assert not (await p1.locator("#s-end").get_attribute("class") or "").count("hide"), "p1 not at end"
            await host.screenshot(path=OUT / "host_end.png"); await p1.screenshot(path=OUT / "player_end.png")
            # rejouer -> lobby
            await host.click("#btn"); await asyncio.sleep(0.6)
            assert "Lancer" == (await host.text_content("#btn")).strip()
            # admin
            adm = await host_ctx.new_page(); adm.on("pageerror", lambda e: errors.append(f"/admin: {e}"))
            await adm.goto("http://127.0.0.1:8080/admin"); await asyncio.sleep(0.8)
            assert len(await adm.input_value("#q")) > 100
            await adm.click("button:not(.g)"); await asyncio.sleep(0.6)
            assert "questions chargees" in await adm.text_content("#msg")
            await adm.screenshot(path=OUT / "admin.png")
            await b.close()
    finally:
        srv.terminate()
    print("E2E OK" if not errors else "E2E errors:"); [print(" ", e) for e in errors]
    sys.exit(1 if errors else 0)

asyncio.run(main())
