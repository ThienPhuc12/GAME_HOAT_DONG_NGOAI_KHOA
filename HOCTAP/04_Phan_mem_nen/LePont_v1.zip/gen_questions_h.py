import json, sys

src = sys.argv[1]
dst = sys.argv[2]
rows = json.load(open(src, encoding="utf-8"))

out = []
for r in rows:
    opts = [r["option_A"], r["option_B"], r["option_C"], r["option_D"]]
    opts = [o for o in opts if o]
    q = {
        "cat": r["categorie"],
        "fr": r["question_fr"],
        "vi": r["question_vi"],
        "o": opts,
        "r": "ABCD".index(r["reponse"]) if r["reponse"] in "ABCD" and r["reponse"] else -1,
        "pfr": r["pont_fr"],
        "pvi": r["pont_vi"],
    }
    if r.get("cible_estimation"):
        q["num"] = int(r["cible_estimation"])
    out.append(q)

body = json.dumps(out, ensure_ascii=False, indent=1)
assert ')json"' not in body

header = '''#pragma once
// =============================================================================
//  LE PONT · CẦU — base de questions (JSON embarqué dans le programme)
//  Format d'une question :
//   {"cat":"Catégorie","fr":"Question en français","vi":"Câu hỏi tiếng Việt",
//    "o":["A","B","C","D"],"r":0,"pfr":"Révélation FR","pvi":"Tiết lộ VI"}
//   r = index de la bonne réponse (0 à 3)
//  Les questions avec "num" (estimation, sans options) sont ignorées en v1 :
//  les faire jouer est l'exercice de vibe coding du soir 2.
//  Tu peux aussi charger des questions sans reflasher : http://192.168.4.1/admin
// =============================================================================
const char QUESTIONS_JSON[] PROGMEM = R"json(
'''
footer = '''
)json";
'''
open(dst, "w", encoding="utf-8").write(header + body + footer)
print(len(out), "questions ->", dst, len(body), "bytes")
